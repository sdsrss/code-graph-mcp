import { f as g } from './t';
export function A(f: () => number) { return g() + f(); }
