import { f } from './b';
export function A() { return f(); }
