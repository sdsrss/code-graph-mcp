function h() { return 0; }
class A {
  h() { return 1; }
}
export function g(o) { o.h(); return o.h() + h(); }
