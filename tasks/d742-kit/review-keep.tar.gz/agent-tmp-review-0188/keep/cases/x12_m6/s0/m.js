class A {
  h() { return 1; }
  k() { return 2; }
}
export function g(o) { o.h(); return o.k(); }
