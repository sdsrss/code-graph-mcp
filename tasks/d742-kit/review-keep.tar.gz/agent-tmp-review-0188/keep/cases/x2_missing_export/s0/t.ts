export function g() { return 1; }
