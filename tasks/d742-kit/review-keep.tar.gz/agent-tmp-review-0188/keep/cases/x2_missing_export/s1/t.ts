export function g() { return 3; }

