export { f } from './t';
export function A() { return f(); }
