export function f() { return 2; }

