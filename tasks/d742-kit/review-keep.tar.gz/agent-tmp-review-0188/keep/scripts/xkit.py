import os, re, sys, shutil, hashlib
# xkit.py SRC DST SALT : JS-family variant of before/after kits: each .js stem gets ts/tsx/js, specifiers lose ".js"
src, dst, salt = sys.argv[1], sys.argv[2], sys.argv[3]
EXT = ["ts", "tsx", "js"]
for case in sorted(os.listdir(src)):
    c = os.path.join(src, case)
    if not os.path.isdir(os.path.join(c, "before")): continue
    files = []
    for side in ("before", "after"):
        for dp, _, fs in os.walk(os.path.join(c, side)):
            for f in fs: files.append((side, os.path.relpath(os.path.join(dp, f), os.path.join(c, side))))
    if any(f.endswith(".rs") for _, f in files): continue
    out = os.path.join(dst, case)
    if os.path.exists(out): shutil.rmtree(out)
    for side, rel in files:
        body = open(os.path.join(c, side, rel)).read()
        if rel.endswith(".js"):
            stem = rel[:-3]
            e = EXT[int(hashlib.md5((salt + case + stem).encode()).hexdigest(), 16) % 3]
            rel = stem + "." + e
            body = re.sub(r"(from\s*|require\(\s*|import\(\s*)(['\"])(\.{1,2}/[^'\"]*?)\.js\2", r"\1\2\3\2", body)
        p = os.path.join(out, side, rel); os.makedirs(os.path.dirname(p), exist_ok=True); open(p, "w").write(body)
