#!/bin/bash
# corp.sh NAME SRC : full index with base and head of a copy; dumps edges+pending
set -e
N="$1"; S="$2"; R=/var/tmp/agent-tmp-review-0188/corp
H=/home/ai/dev/code-graph-mcp/tasks/d714-resolver-precision/walk-harness
for arm in base head; do
  D="$R/$N-$arm"; rm -rf "${D:?}"; mkdir -p "$D"
  (cd "$S" && tar --exclude=.code-graph -cf - .) | tar -xf - -C "$D"
  t0=$(date +%s%N)
  (cd "$D" && /var/tmp/agent-tmp-review-0188/bin/$arm incremental-index --no-embed --quiet >/dev/null 2>&1)
  t1=$(date +%s%N)
  "$H/edgesm.sh" "$D" > "$R/$N-$arm.edges"
  sqlite3 -readonly "file:$D/.code-graph/index.db?mode=ro" "SELECT COALESCE(f.path,'?')||':'||n.name||'@'||n.start_line||' => '||p.target_name||' '||p.source_language||' '||COALESCE(p.metadata,'') FROM pending_unresolved_calls p JOIN nodes n ON n.id=p.source_id LEFT JOIN files f ON f.id=n.file_id" | sort > "$R/$N-$arm.pend"
  echo "$N $arm ms=$(( (t1-t0)/1000000 )) edges=$(wc -l < $R/$N-$arm.edges) pend=$(wc -l < $R/$N-$arm.pend)"
done
