#!/bin/bash
# run.sh BIN CASE... : ivchain over each case dir
B="$(realpath "$1")"; shift
for c in "$@"; do echo "== $(basename $c) [$(basename $B)]: $(/home/ai/dev/code-graph-mcp/tasks/d714-resolver-precision/walk-harness/ivchain.sh "$B" "$(realpath "$c")" 2>&1)"; done
