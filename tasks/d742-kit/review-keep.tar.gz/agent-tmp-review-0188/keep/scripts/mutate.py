import sys, subprocess, shutil, os, re, time
# mutate.py ID : apply mutation ID to mut/, run cargo test --lib, restore
R = "/var/tmp/agent-tmp-review-0188"
IF = "src/indexer/pipeline/index_files.rs"; RS = "src/indexer/pipeline/resolve.rs"
M = {
 "M1": (IF, "if sources.len() * targets.len() < 2 {", "if sources.len() * targets.len() < 1 {"),
 "M2": (IF, "            self.seen.clear();\n", ""),
 "M3": (IF, "            metadata.map(str::to_string),\n            allow_self,\n        ))", "            None,\n            allow_self,\n        ))"),
 "M4": (IF, "            relation.to_string(),\n            metadata.map(str::to_string),", "            String::new(),\n            metadata.map(str::to_string),"),
 "M5": (IF, "if sources.len() * targets.len() < 2 {", "if true {"),
 "M6": (RS, "    if let Some(pool) = pools.get(name) {", "    if let Some(pool) = pools.get(\"\") {"),
 "M7": (RS, "    pools.insert(name.to_string(), pool.clone());", "    pools.insert(name.to_string(), candidates.clone());"),
 "M8": (IF, "                if q != name {", "                if false {"),
 "M9": (IF, "                        || rust_impl && kind == \"interface\")", ")"),
 "M10": (IF, "let pending_resolved = if all_indexed.is_empty() && delete_paths.is_empty() {", "let pending_resolved = if all_indexed.is_empty() {"),
 "M11": (RS, "    JS_FAMILY.contains(&caller) && metadata.is_none()", "    JS_FAMILY.contains(&caller)"),
 "M12": (RS, ".filter(|(_, seen)| matches!(seen, Some((_, true))))", ".filter(|(_, seen)| seen.is_some())"),
 "M13": (RS, "                    .filter(|(t, _)| *t == target)", "                    .filter(|_| true)"),
 "M14": (RS, "    caller != callee && JS_FAMILY.contains(&caller)", "    JS_FAMILY.contains(&caller)"),
 "M15": (RS, "        if candidates.is_empty()\n            && may_widen_to_family(", "        if candidates.iter().all(|id| *id == row.source_id)\n            && may_widen_to_family("),
 "M16": (IF, "                if imported.contains(&(d.rel_path.clone(), d.target_name.clone())) {", "                if true {"),
 "M18": (RS, "                candidates = pool(&|l| family_fallback(&row.source_language, l));", "                {}"),
 "M20": (IF, "            written.enter(&d.rel_path);\n            edges_created += insert_relation_edges(\n                db,\n                written,", "            edges_created += insert_relation_edges(\n                db,\n                written,"),
 "M21": (RS, "           AND json_extract(ie.metadata, '$.attr') IS NULL\",\n    )?;\n    let rows = stmt.query_map", "           \",\n    )?;\n    let rows = stmt.query_map"),
 "M22": (IF, "    let pending_resolved = if all_indexed.is_empty() && delete_paths.is_empty() {", "    let pending_resolved = if false {"),
 "M23": (IF, "            if same_language_targets.is_empty()\n                && super::resolve::may_widen_to_family(&d.language, call_meta)", "            if false\n                && super::resolve::may_widen_to_family(&d.language, call_meta)"),
 "M11b": (RS, "    JS_FAMILY.contains(&caller) && metadata.is_none()", "    JS_FAMILY.contains(&caller) && (metadata.is_none() || caller.len() > 0)"),
 "M16b": (IF, "                if imported.contains(&(d.rel_path.clone(), d.target_name.clone())) {", "                if imported.contains(&(d.rel_path.clone(), d.target_name.clone())) || d.rel_path.len() > 0 {"),
 "M24": (RS, "pub(super) fn may_widen_to_family(caller: &str, metadata: Option<&str>) -> bool {\n    JS_FAMILY.contains(&caller) && metadata.is_none()", "pub(super) fn may_widen_to_family(caller: &str, metadata: Option<&str>) -> bool {\n    JS_FAMILY.contains(&caller) && metadata.is_none() && caller.is_empty()"),
 "M3b": (IF, "            metadata.map(str::to_string),\n            allow_self,\n        ))", "            metadata.map(|_| String::new()),\n            allow_self,\n        ))"),
 "M4b": (IF, "            relation.to_string(),\n            metadata.map(str::to_string),", "            {\n                let _ = relation;\n                String::new()\n            },\n            metadata.map(str::to_string),"),
}
mid = sys.argv[1]
path, old, new = M[mid]
src = os.path.join(R, "src", path); dst = os.path.join(R, "mut", path)
text = open(src).read()
n = text.count(old)
if n != 1:
    print(f"{mid}: pattern count {n}, skipped"); sys.exit(1)
open(dst, "w").write(text.replace(old, new))
try:
    env = dict(os.environ, CARGO_TARGET_DIR=R + "/target-mut", PATH=os.environ["HOME"] + "/.cargo/bin:" + os.environ["PATH"])
    t0 = time.time()
    p = subprocess.run(["cargo", "test", "--lib", "--", "--test-threads=12"], cwd=R + "/mut", env=env, capture_output=True, text=True)
    out = p.stdout + p.stderr
    open(f"{R}/mutres/{mid}.log", "w").write(out)
    if "error[E" in out or "could not compile" in out:
        print(f"{mid}: COMPILE ERROR"); sys.exit(0)
    failed = sorted(set(re.findall(r"^    (\S+)$", out.split("failures:")[-1], re.M))) if "failures:" in out else []
    res = re.findall(r"test result: \S+\. (\d+) passed; (\d+) failed", out)
    print(f"{mid}: {res} failed={failed} ({time.time()-t0:.0f}s)")
finally:
    shutil.copy(src, dst)
