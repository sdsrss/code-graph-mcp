#!/bin/bash
# timeit.sh ARM SHAPE : full index of a fresh copy, prints ms and call-edge count
R=/var/tmp/agent-tmp-review-0188; A="$1"; S="$2"; D="$R/perfrun/$S-$A"
rm -rf "${D:?}"; mkdir -p "$D"; cp -a "$R/perf/$S/." "$D/"; (cd "$D" && git init -q && git add -A && git -c user.email=a@b -c user.name=a commit -qm i)
t0=$(date +%s%N); (cd "$D" && "$R/bin/$A" incremental-index --no-embed --quiet >/dev/null 2>&1); t1=$(date +%s%N)
echo "$S $A ms=$(( (t1-t0)/1000000 )) calls=$(sqlite3 "$D/.code-graph/index.db" "select count(*) from edges where relation='calls'")"
