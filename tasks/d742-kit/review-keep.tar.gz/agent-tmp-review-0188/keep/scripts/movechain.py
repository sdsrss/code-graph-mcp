# movechain.py BIN CORPUS N SEED WORK: on a corpus copy, move N files that end JS-family cross-language
# call edges between .ts/.tsx/.js (both ends), then back; after each step compare incremental vs rebuild
import os, random, shutil, subprocess, sys, sqlite3
bin_, corpus, n, seed, work = sys.argv[1], sys.argv[2], int(sys.argv[3]), int(sys.argv[4]), sys.argv[5]
H = "/home/ai/dev/code-graph-mcp/tasks/d714-resolver-precision/walk-harness"
W = os.path.join(work, f"mv-{os.path.basename(corpus)}-{seed}-{os.path.basename(bin_)}"); F = W + "-full"
for d in (W, F):
    if os.path.exists(d): shutil.rmtree(d)
shutil.copytree(corpus, W, symlinks=True); shutil.rmtree(f"{W}/.code-graph", ignore_errors=True)
idx = lambda d: subprocess.run([bin_, "incremental-index", "--no-embed", "--quiet"], cwd=d, capture_output=True, timeout=1200)
def dump(d):
    e = subprocess.run([f"{H}/edgesm.sh", d], capture_output=True, text=True).stdout
    db = sqlite3.connect(f"file:{d}/.code-graph/index.db?mode=ro", uri=True)
    p = sorted("PENDING %s:%s => %s %s" % r for r in db.execute("SELECT COALESCE(f.path,'?'), n.name, p.target_name, COALESCE(p.metadata,'') FROM pending_unresolved_calls p JOIN nodes n ON n.id=p.source_id LEFT JOIN files f ON f.id=n.file_id"))
    return e + "\n".join(p)
def commit(d): subprocess.run("git add -A && git -c user.email=a@b -c user.name=a commit -qm e", shell=True, cwd=d, capture_output=True)
idx(W)
db = sqlite3.connect(f"file:{W}/.code-graph/index.db?mode=ro", uri=True)
ends = set()
for (sp, tp) in db.execute("""SELECT DISTINCT fs.path, ft.path FROM edges e JOIN nodes s ON s.id=e.source_id JOIN files fs ON fs.id=s.file_id
    JOIN nodes t ON t.id=e.target_id JOIN files ft ON ft.id=t.file_id
    WHERE e.relation='calls' AND fs.language IN ('typescript','tsx','javascript') AND ft.language IN ('typescript','tsx','javascript')
      AND fs.path<>ft.path"""):
    ends.add(sp); ends.add(tp)
db.close()
ends = sorted(p for p in ends if p.endswith((".ts", ".tsx")) and not p.endswith(".d.ts"))
rng = random.Random(seed); pick = rng.sample(ends, min(n, len(ends)))
diffs = 0
for f in pick:
    to = f[:-3] + ".tsx" if f.endswith(".ts") else f[:-4] + ".ts"
    if os.path.exists(f"{W}/{to}"): continue
    for step, (a, b) in (("move", (f, to)), ("back", (to, f))):
        os.rename(f"{W}/{a}", f"{W}/{b}"); commit(W); idx(W)
        if os.path.exists(F): shutil.rmtree(F)
        shutil.copytree(W, F, symlinks=True, ignore=shutil.ignore_patterns(".code-graph")); idx(F)
        x, y = dump(W), dump(F)
        if x != y:
            diffs += 1
            sa, sb = set(x.splitlines()), set(y.splitlines())
            print(f"{step} {a} -> {b}: incremental-only {len(sa-sb)} rebuild-only {len(sb-sa)}", flush=True)
            for l in sorted(sa - sb)[:4]: print("   inc:", l[:200])
            for l in sorted(sb - sa)[:4]: print("   full:", l[:200])
print(f"{os.path.basename(corpus)} [{os.path.basename(bin_)}]: candidates {len(ends)}, picked {len(pick)}, diff steps {diffs}")
shutil.rmtree(W); shutil.rmtree(F, ignore_errors=True)
