# mk.py ROOT NAME : reads a spec from stdin: "== sN" starts a state; "-- path" starts a file; lines follow
import os, sys
root, name = sys.argv[1], sys.argv[2]
d = os.path.join(root, name)
import shutil
if os.path.exists(d): shutil.rmtree(d)
state = None; path = None; buf = {}
files = {}
for line in sys.stdin.read().split('\n'):
    if line.startswith('== '):
        state = line[3:].strip(); files[state] = {}; path = None
    elif line.startswith('-- '):
        path = line[3:].strip(); files[state][path] = ''
    elif path is not None:
        files[state][path] += line + '\n'
# states inherit: a file absent in a later state but present before is kept unless marked "!DEL"
prev = {}
for st in sorted(files, key=lambda s: int(s[1:])):
    cur = dict(prev)
    for p, b in files[st].items():
        if b.strip() == '!DEL': cur.pop(p, None)
        else: cur[p] = b
    for p, b in cur.items():
        fp = os.path.join(d, st, p); os.makedirs(os.path.dirname(fp), exist_ok=True)
        open(fp, 'w').write(b)
    prev = cur
