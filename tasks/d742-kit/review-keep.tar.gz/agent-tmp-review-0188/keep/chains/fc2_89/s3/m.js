export function M() { return f(); }
// touched 1
