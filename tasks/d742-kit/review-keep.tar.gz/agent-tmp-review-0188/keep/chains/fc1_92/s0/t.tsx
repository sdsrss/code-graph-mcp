export function f() { return 1; }
export function q() { return f(); }
