import { f } from './u';
export function B() { return f(); }
