import { f } from './t';
export function K(o: any) { o.f(); return f(); }
// touched 1
