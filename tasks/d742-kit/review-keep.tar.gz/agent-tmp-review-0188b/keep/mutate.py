import subprocess, sys, os, re, shutil
# mutate.py: apply each mutation to the mut copy, run cargo test --lib, restore.
ROOT = "/var/tmp/agent-tmp-review-0188b/mut"
IF = "src/indexer/pipeline/index_files.rs"
RS = "src/indexer/pipeline/resolve.rs"
M = [
 ("M1 walked flag ignored", RS,
  ".map(|(k, s)| (k, s.filter(|(_, walked)| *walked).map(|(t, _)| t)))",
  ".map(|(k, s)| (k, s.map(|(t, _)| t)))"),
 ("M2 second import target kept (first wins)", RS,
  ".filter(|(t, _)| *t == target)", ".filter(|(t, _)| *t == *t)"),
 ("M3 deferred: import target bound even if not a same-name sibling", IF,
  "if siblings.contains(&target) {\n                            same_language_targets = vec![target];",
  "if true {\n                            same_language_targets = vec![target];"),
 ("M4 sweep: import target bound even if not a same-name sibling", RS,
  "if siblings.contains(&target) {\n                        candidates = vec![target];",
  "if true {\n                        candidates = vec![target];"),
 ("M5 sweep: whole sibling pool (89689052 rule)", RS,
  "candidates = vec![target];", "candidates = siblings.clone();"),
 ("M6 deferred: whole sibling pool (89689052 rule)", IF,
  "same_language_targets = vec![target];", "same_language_targets = siblings.clone();"),
 ("M7 always age", IF, "            !all_indexed.is_empty(),\n        )?", "            true,\n        )?"),
 ("M8 never age in index_files", IF, "            !all_indexed.is_empty(),\n        )?", "            false,\n        )?"),
 ("M9 family fan-out arm selects nothing", RS,
  "WHERE u.lang IN ('javascript', 'typescript', 'tsx')", "WHERE 0 AND u.lang IN ('javascript', 'typescript', 'tsx')"),
 ("M10 family arm: caller of any language", RS,
  "CROSS JOIN files f ON f.id = src.file_id AND f.language IS u.lang\n         WHERE u.lang IN",
  "CROSS JOIN files f ON f.id = src.file_id\n         WHERE u.lang IN"),
 ("M11 deferred-side widening off (sweep only)", IF,
  "&& super::resolve::may_widen_to_family(&d.language, call_meta)",
  "&& false && super::resolve::may_widen_to_family(&d.language, call_meta)"),
 ("M12 sweep-side widening off (deferred only)", RS,
  "&& may_widen_to_family(&row.source_language, row.metadata.as_deref())",
  "&& false && may_widen_to_family(&row.source_language, row.metadata.as_deref())"),
 ("M13 FileImports keyed by target name, not imported name", RS,
  "\"SELECT COALESCE(json_extract(ie.metadata, '$.imported'), itn.name),\n                        itn.id,",
  "\"SELECT itn.name,\n                        itn.id,"),
 ("M14 FileImports counts <external> sentinels", RS,
  "                 WHERE f.path = ?1\n                   AND itf.path <> '<external>'",
  "                 WHERE f.path = ?1\n                   AND 1"),
 ("M15 walked resolved from the project root, not the importer's dir", RS,
  "resolve_js_specifier_path(&spec, file, files).is_some()",
  "resolve_js_specifier_path(&spec, \"x\", files).is_some()"),
 ("M16 family arm also requires the edge be ambiguous", RS,
  "CROSS JOIN edges e ON e.target_id = tgt.id AND e.relation = '{REL_CALLS}'\n         CROSS JOIN nodes src ON src.id = e.source_id\n         CROSS JOIN files f ON f.id = src.file_id AND f.language IS u.lang",
  "CROSS JOIN edges e ON e.target_id = tgt.id AND e.relation = '{REL_CALLS}' AND e.confidence = 'ambiguous'\n         CROSS JOIN nodes src ON src.id = e.source_id\n         CROSS JOIN files f ON f.id = src.file_id AND f.language IS u.lang"),
]
sel = sys.argv[1:]
env = dict(os.environ, CARGO_TARGET_DIR="/var/tmp/agent-tmp-review-0188b/mut-target",
           PATH=os.environ["HOME"] + "/.cargo/bin:" + os.environ["PATH"])
out = open("/var/tmp/agent-tmp-review-0188b/mutation-results.txt", "a")
for name, f, old, new in M:
    mid = name.split()[0]
    if sel and mid not in sel:
        continue
    p = os.path.join(ROOT, f)
    src = open(p).read()
    n = src.count(old)
    if n != 1:
        out.write(f"{name}: ANCHOR COUNT {n}, skipped\n"); out.flush(); continue
    open(p, "w").write(src.replace(old, new))
    try:
        r = subprocess.run(["cargo", "test", "--lib"], cwd=ROOT, env=env, capture_output=True, text=True)
        txt = r.stdout + r.stderr
        res = re.findall(r"test result: \w+\. (\d+) passed; (\d+) failed", txt)
        failed = re.findall(r"^    (\S+)$", txt, re.M)
        if not res:
            err = [l for l in txt.splitlines() if l.startswith("error")][:3]
            out.write(f"{name}: NO TEST RESULT (build failed?) {err}\n")
        else:
            out.write(f"{name}: passed={res[-1][0]} failed={res[-1][1]} failing={failed}\n")
        out.flush()
    finally:
        open(p, "w").write(src)
out.close()
