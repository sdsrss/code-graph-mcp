#!/bin/bash
# timing.sh DIR EDITFILE: alternate base-src and cand, 3 runs each: fresh full index ms, then one-file edit ms
D="$1"; E="$2"; B=/var/tmp/agent-tmp-d745/bin/base-src; C=/var/tmp/agent-tmp-review-0188b/cand
full=""; edit=""
for i in 1 2 3; do
  for arm in base cand; do
    bin=$B; [ $arm = cand ] && bin=$C
    rm -rf "${D:?}/.code-graph"
    s=$(date +%s%N); (cd "$D" && "$bin" incremental-index --no-embed --quiet >/dev/null 2>&1); e=$(date +%s%N)
    full="$full $arm=$(( (e-s)/1000000 ))"
    printf '// edit %s %s\n' "$i" "$arm" >> "$D/$E"
    s=$(date +%s%N); (cd "$D" && "$bin" incremental-index --no-embed --quiet >/dev/null 2>&1); e=$(date +%s%N)
    edit="$edit $arm=$(( (e-s)/1000000 ))"
  done
done
echo "$(basename "$D") full:$full"
echo "$(basename "$D") edit($E):$edit"
