import os, shutil, sys
# manual.py ROOT: hand-written chains, each a list of full trees s0..sN
root = sys.argv[1]
LONG = "/* " + "x" * 4200 + " */"
def caller(imp="import { f } from './t';", body="return f();", ext_any=True, name="A", pre=""):
    return f"{imp}\n{pre}export function {name}(o{': any' if ext_any else ''}) {{ {body} }}\n"
F = "export function f() { return 1; }\n"
CH = {
 # restore of an inbound call onto every same-name node of the callee file
 "restore_method_long": [
   {"a.tsx": caller(body=LONG + " return f();"), "t.ts": F},
   {"a.tsx": caller(body=LONG + " return f();"), "t.ts": F + "export class K { f() { return 2; } }\n"},
 ],
 "restore_method_long_samelang": [
   {"a.ts": caller(body=LONG + " return f();"), "t.ts": F},
   {"a.ts": caller(body=LONG + " return f();"), "t.ts": F + "export class K { f() { return 2; } }\n"},
 ],
 "restore_method_member": [
   {"a.tsx": caller(body="o.f(); return f();"), "t.ts": F},
   {"a.tsx": caller(body="o.f(); return f();"), "t.ts": F + "export class K { f() { return 2; } }\n"},
 ],
 "restore_nested_long": [
   {"a.tsx": caller(body=LONG + " return f();"), "t.ts": F},
   {"a.tsx": caller(body=LONG + " return f();"), "t.ts": F + "export function h() { function f() { return 3; } return f(); }\n"},
 ],
 # t.ts keeps a node named f but the import now targets a renamed export
 "restore_renamed_kept_local": [
   {"a.tsx": caller(), "t.ts": F},
   {"a.tsx": caller(), "t.ts": "function f() { return 1; }\nfunction r() { return 2; }\nexport { r as f };\n"},
 ],
 # an import of an unindexed path becomes walked when the file appears
 "unwalked_to_walked": [
   {"a.tsx": caller(imp="import { f } from './d/t';"), "t.ts": F},
   {"a.tsx": caller(imp="import { f } from './d/t';"), "t.ts": F, "d/t.js": "export function f() { return 2; }\n"},
 ],
 "walked_to_unwalked": [
   {"a.tsx": caller(imp="import { f } from './d/t';"), "t.ts": F, "d/t.js": "export function f() { return 2; }\n"},
   {"a.tsx": caller(imp="import { f } from './d/t';"), "t.ts": F},
 ],
 # an own-language definition appears by an edit (no new file), no guard
 "own_lang_by_edit": [
   {"a.tsx": caller(), "t.ts": F, "c.tsx": "export const w = 1;\n"},
   {"a.tsx": caller(), "t.ts": F, "c.tsx": "export function f() { return 2; }\n"},
 ],
 # an own-language definition goes by an edit (no deletion), guard keeps it
 "own_lang_goes_by_edit_long": [
   {"a.tsx": caller(body=LONG + " return f();"), "t.ts": F, "b.tsx": "export function f() { return 2; }\n"},
   {"a.tsx": caller(body=LONG + " return f();"), "t.ts": F, "b.tsx": "export const w = 2;\n"},
 ],
 "own_lang_goes_by_edit_member": [
   {"a.tsx": caller(body="o.f(); return f();"), "t.ts": F, "b.tsx": "export function f() { return 2; }\n"},
   {"a.tsx": caller(body="o.f(); return f();"), "t.ts": F, "b.tsx": "export const w = 2;\n"},
 ],
 # the specifier resolves to another extension once one goes
 "spec_moves_ts_to_js": [
   {"a.tsx": caller(), "t.ts": F, "t.js": "export function f() { return 2; }\n"},
   {"a.tsx": caller(), "t.js": "export function f() { return 2; }\n"},
 ],
 "spec_gains_ts_over_js": [
   {"a.tsx": caller(), "t.js": "export function f() { return 2; }\n"},
   {"a.tsx": caller(), "t.ts": F, "t.js": "export function f() { return 2; }\n"},
 ],
 "spec_gains_tsx_same_lang": [
   {"a.tsx": caller(), "t.js": "export function f() { return 2; }\n"},
   {"a.tsx": caller(), "t.tsx": "export function f() { return 3; }\n", "t.js": "export function f() { return 2; }\n"},
 ],
 # default and namespace imports
 "default_import": [
   {"a.tsx": caller(imp="import f from './t';"), "t.ts": "export default function f() { return 1; }\n"},
   {"a.tsx": caller(imp="import f from './t';"), "t.ts": "export default function g() { return 1; }\nexport function f() { return 2; }\n"},
 ],
 "default_import_other_name": [
   {"a.tsx": caller(imp="import g from './t';", body="return g() + f();"), "t.ts": "export default function f() { return 1; }\n"},
   {"a.tsx": caller(imp="import g from './t';", body="return g() + f();"), "t.ts": "export default function f() { return 1; }\n", "u.js": F},
 ],
 # barrels
 "star_barrel_second_source": [
   {"a.tsx": caller(imp="import { f } from './b';"), "b.ts": "export * from './t';\nexport * from './u';\n", "t.ts": F, "u.js": "export const y = 1;\n"},
   {"a.tsx": caller(imp="import { f } from './b';"), "b.ts": "export * from './t';\nexport * from './u';\n", "t.ts": F, "u.js": "export function f() { return 9; }\n"},
 ],
 "star_barrel_source_loses": [
   {"a.tsx": caller(imp="import { f } from './b';"), "b.ts": "export * from './t';\nexport * from './u';\n", "t.ts": F, "u.js": "export function f() { return 9; }\n"},
   {"a.tsx": caller(imp="import { f } from './b';"), "b.ts": "export * from './t';\nexport * from './u';\n", "t.ts": F, "u.js": "export const y = 1;\n"},
 ],
 "barrel_retarget": [
   {"a.tsx": caller(imp="import { f } from './b';"), "b.ts": "export { f } from './t';\n", "t.ts": F, "u.js": "export function f() { return 9; }\n"},
   {"a.tsx": caller(imp="import { f } from './b';"), "b.ts": "export { f } from './u';\n", "t.ts": F, "u.js": "export function f() { return 9; }\n"},
 ],
 "barrel_deleted": [
   {"a.tsx": caller(imp="import { f } from './b';"), "b.ts": "export { f } from './t';\n", "t.ts": F},
   {"a.tsx": caller(imp="import { f } from './b';"), "t.ts": F},
 ],
 # a second import of the name appears in another statement of the caller (caller edited)
 "second_import_appears": [
   {"a.tsx": caller(), "t.ts": F, "v.js": F},
   {"a.tsx": caller(imp="import { f } from './t';\nimport { f as g } from './v';", body="return f() + g();"), "t.ts": F, "v.js": F},
 ],
 # the import target file moves language and the caller's language
 "callee_moves_to_caller_lang": [
   {"a.tsx": caller(), "t.ts": F},
   {"a.tsx": caller(), "t.tsx": F},
 ],
 "caller_moves_to_callee_lang": [
   {"a.tsx": caller(), "t.ts": F},
   {"a.ts": caller(), "t.ts": F},
 ],
 "caller_moves_to_js": [
   {"a.tsx": caller(), "t.ts": F, "c.tsx": "export function f() { return 5; }\n"},
   {"a.js": caller(ext_any=False), "t.ts": F, "c.tsx": "export function f() { return 5; }\n"},
 ],
 # a second definition of f in the imported file (pool of the import, same file)
 "callee_gains_overload": [
   {"a.tsx": caller(), "t.ts": F},
   {"a.tsx": caller(), "t.ts": "export function f(): number;\nexport function f(x?: number) { return 1; }\n"},
 ],
 # deletion-only: the caller's own-language definition goes, prune guard by member call
 "own_lang_deleted_member": [
   {"a.tsx": caller(body="o.f(); return f();"), "t.ts": F, "b.tsx": "export function f() { return 2; }\n"},
   {"a.tsx": caller(body="o.f(); return f();"), "t.ts": F},
 ],
 # sweep-only path: a pending row whose import becomes unique by an edit of another file
 "subdir_caller": [
   {"src/a.tsx": caller(imp="import { f } from '../lib/t';"), "lib/t.ts": F},
   {"src/a.tsx": caller(imp="import { f } from '../lib/t';"), "lib/t.ts": F, "lib/c.js": F},
 ],
 "subdir_callee_arrives": [
   {"src/a.tsx": caller(imp="import { f } from '../lib/t';")},
   {"src/a.tsx": caller(imp="import { f } from '../lib/t';"), "lib/t.ts": F},
 ],
 # self-name: the caller is itself named f
 "caller_named_f": [
   {"a.tsx": "import { f as g } from './t';\nexport function f() { return g(); }\nexport function A() { return f(); }\n", "t.ts": F},
   {"a.tsx": "import { f as g } from './t';\nexport function f() { return g(); }\nexport function A() { return f(); }\n", "t.ts": F, "c.js": F},
 ],
 # commonjs require
 "require_destructure": [
   {"a.js": "const { f } = require('./t');\nfunction A() { return f(); }\nmodule.exports = { A };\n", "t.ts": F},
   {"a.js": "const { f } = require('./t');\nfunction A() { return f(); }\nmodule.exports = { A };\n", "t.ts": F, "c.tsx": "export function f() { return 2; }\n"},
 ],
}
for name, steps in CH.items():
    d = os.path.join(root, name)
    if os.path.exists(d):
        shutil.rmtree(d)
    for i, tree in enumerate(steps):
        for fn, body in tree.items():
            p = os.path.join(d, f"s{i}", fn)
            os.makedirs(os.path.dirname(p), exist_ok=True)
            open(p, "w").write(body)
