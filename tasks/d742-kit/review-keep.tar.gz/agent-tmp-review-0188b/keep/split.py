import sqlite3, sys, posixpath, json
# split.py DB DIFFFILE: for each added call edge line, classify by the caller file's import of the target
db = sqlite3.connect(f"file:{sys.argv[1]}?mode=ro", uri=True)
files = set(r[0] for r in db.execute("SELECT path FROM files"))
EXT = ["ts", "tsx", "js", "jsx", "mjs", "cjs"]
def resolve(spec, imp):
    if spec in (".", ".."): spec += "/"
    if not (spec.startswith("./") or spec.startswith("../")): return None
    d = imp.rsplit("/", 1)[0] if "/" in imp else ""
    base = posixpath.normpath(posixpath.join(d, spec)) if d else posixpath.normpath(spec)
    if base.startswith(".."): return None
    if base == ".": base = ""
    if base in files: return base
    for e in EXT:
        if f"{base}.{e}" in files: return f"{base}.{e}"
    for e in EXT:
        c = f"index.{e}" if base == "" else f"{base}/index.{e}"
        if c in files: return c
    return None
own = via = none = 0; samples = []
for line in open(sys.argv[2]):
    if not line.startswith(">") or "-calls->" not in line: continue
    l = line[2:].split(" -calls-> ")
    src_file, rest = l[0].rsplit(":", 1)[0], l[0]
    src_name = l[0].rsplit(":", 1)[1].split("@")[0]
    tgt = l[1].split(" ")[0]
    tfile = tgt.split(":")[0]; tname = tgt.split(":")[1].split("@")[0]; tline = int(tgt.split("@")[1].split(":")[0])
    rows = db.execute("""SELECT json_extract(e.metadata,'$.js_module'), tf.path FROM edges e
        JOIN nodes s ON s.id=e.source_id JOIN files sf ON sf.id=s.file_id
        JOIN nodes t ON t.id=e.target_id JOIN files tf ON tf.id=t.file_id
        WHERE e.relation='imports' AND sf.path=? AND tf.path=? AND t.name=? AND t.start_line=?""",
        (src_file, tfile, tname, tline)).fetchall()
    if not rows:
        none += 1; samples.append(("NOIMPORT", line.strip())); continue
    res = set(resolve(spec, src_file) for spec, _ in rows if spec)
    if tfile in res: own += 1
    else:
        via += 1
        if len(samples) < 6: samples.append(("VIA", line.strip()[:150], res))
print(f"own={own} via={via} no_import={none} total={own+via+none}")
for s in samples[:8]: print(s)
