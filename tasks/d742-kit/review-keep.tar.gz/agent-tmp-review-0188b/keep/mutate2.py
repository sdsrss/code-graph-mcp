import subprocess, os, re
ROOT = "/var/tmp/agent-tmp-review-0188b/mut"
IF = "src/indexer/pipeline/index_files.rs"; RS = "src/indexer/pipeline/resolve.rs"
M = [
 ("M7", [(IF, "            !all_indexed.is_empty(),\n        )?", "            true,\n        )?")], "a_deletion_ages"),
 ("M9", [(RS, "WHERE u.lang IN ('javascript', 'typescript', 'tsx')", "WHERE 0 AND u.lang IN ('javascript', 'typescript', 'tsx')")], "a_js_family"),
 ("M12", [(RS, "&& may_widen_to_family(&row.source_language, row.metadata.as_deref())", "&& false && may_widen_to_family(&row.source_language, row.metadata.as_deref())")], "a_js_family"),
 ("M17 metadata gate dropped", [(RS, "JS_FAMILY.contains(&caller) && metadata.is_none()", "JS_FAMILY.contains(&caller)")], "a_js_family"),
 ("M18 widening off both sides", [(IF, "&& super::resolve::may_widen_to_family(&d.language, call_meta)", "&& false && super::resolve::may_widen_to_family(&d.language, call_meta)"),
                                  (RS, "&& may_widen_to_family(&row.source_language, row.metadata.as_deref())", "&& false && may_widen_to_family(&row.source_language, row.metadata.as_deref())")], "a_js_family"),
]
env = dict(os.environ, CARGO_TARGET_DIR="/var/tmp/agent-tmp-review-0188b/mut-target", PATH=os.environ["HOME"] + "/.cargo/bin:" + os.environ["PATH"])
out = open("/var/tmp/agent-tmp-review-0188b/mutation-detail.txt", "w")
for name, edits, filt in M:
    saved = {}
    ok = True
    for f, old, new in edits:
        p = os.path.join(ROOT, f); s = saved.get(p) or open(p).read(); saved.setdefault(p, s)
        cur = open(p).read()
        if cur.count(old) != 1: ok = False; break
        open(p, "w").write(cur.replace(old, new))
    try:
        if not ok:
            out.write(f"== {name}: ANCHOR MISSING\n"); continue
        r = subprocess.run(["cargo", "test", "--lib", filt], cwd=ROOT, env=env, capture_output=True, text=True)
        txt = r.stdout + r.stderr
        res = re.findall(r"test result: .*", txt)
        out.write(f"== {name}: {res}\n")
        body = re.findall(r"---- .*? stdout ----\n(.*?)\n\n", txt, re.S)
        for b in body: out.write(b[:6000] + "\n")
        out.flush()
    finally:
        for p, s in saved.items(): open(p, "w").write(s)
out.close()
