import * as ns from './index.js';
export function main() { return ns.init(); }
