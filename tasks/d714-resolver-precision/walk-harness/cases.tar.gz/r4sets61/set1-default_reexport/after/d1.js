export default function init() { return 5; }
