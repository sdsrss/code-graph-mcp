export default function init() { return 6; }
