export { default } from './d2.js';
