import { init } from './index';
export function main() { return init(); }
