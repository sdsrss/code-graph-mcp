import { get } from './index.js';
export function main() { return get(); }
