export { get } from './crud2.js';
