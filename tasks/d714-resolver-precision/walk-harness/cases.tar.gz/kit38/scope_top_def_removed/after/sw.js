function g(x) {
  switch (x) {
    case 1:
      const f = () => 1;
      f();
      break;
    default:
      f();
  }
  return f();
}
