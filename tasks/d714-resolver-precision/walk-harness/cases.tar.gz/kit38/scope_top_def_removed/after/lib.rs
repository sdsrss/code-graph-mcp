fn a(x: bool) -> i32 {
    unsafe {
        fn h() -> i32 { 1 }
        h();
    }
    let fut = async {
        fn h() -> i32 { 2 }
        h()
    };
    loop {
        fn h() -> i32 { 3 }
        h();
        break;
    }
    let c = || { fn h() -> i32 { 4 } h() };
    match x {
        true => { fn h() -> i32 { 5 } h(); }
        false => {}
    }
    {
        fn h() -> i32 { 6 }
        struct S;
        impl S { fn m(&self) -> i32 { h() } }
    }
    {
        h();
        fn later() {}
        fn h() -> i32 { 7 }
    }
    'blk: {
        fn h() -> i32 { 8 }
        h();
        break 'blk;
    }
    const _: () = { fn h() -> i32 { 9 } let _ = h(); };
    h()
}
fn b() -> i32 { h() }
