import { init } from './state';
export function main() { return init(); }
