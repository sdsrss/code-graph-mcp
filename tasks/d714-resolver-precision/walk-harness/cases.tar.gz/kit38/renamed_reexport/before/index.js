export { init as boot } from './crud.js';
