import { boot } from './index.js';
export function main() { return boot(); }
