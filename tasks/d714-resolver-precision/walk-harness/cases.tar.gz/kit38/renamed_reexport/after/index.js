export { init as boot } from './crud2.js';
