export function other3() {}
export function init() { return 3; }
