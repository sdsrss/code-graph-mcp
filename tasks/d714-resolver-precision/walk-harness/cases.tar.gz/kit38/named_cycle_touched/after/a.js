export { init } from './b.js';
export function other() {}
