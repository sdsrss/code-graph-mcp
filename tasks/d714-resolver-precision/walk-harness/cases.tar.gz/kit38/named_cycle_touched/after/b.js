export { init } from './a.js';
export function init2() {}
