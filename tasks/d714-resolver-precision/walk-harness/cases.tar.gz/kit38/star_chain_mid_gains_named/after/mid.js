export function other() {}
export { init } from './crud2.js';
