const { init } = require('./index.js');
function main() { return init(); }
module.exports = { main };
