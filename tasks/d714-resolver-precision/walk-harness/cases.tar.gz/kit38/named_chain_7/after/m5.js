export { init } from './m6.js';
