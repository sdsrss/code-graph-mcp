export { init } from './m5.js';
