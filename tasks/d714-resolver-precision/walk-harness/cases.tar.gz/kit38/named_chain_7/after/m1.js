export { init } from './m2.js';
