function init() { return 4; }
export function t() { return init(); }
