export function init() { return 2; }
export function other2() { return 2; }
