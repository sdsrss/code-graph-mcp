import { init } from './index.js';
export function main() { return init(); }
