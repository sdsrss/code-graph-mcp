export { init } from './crud2.js';
