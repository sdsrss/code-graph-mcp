export function init() { return 1; }
export function other1() { return 1; }
