import { init } from './crud2.js';
export { init };
