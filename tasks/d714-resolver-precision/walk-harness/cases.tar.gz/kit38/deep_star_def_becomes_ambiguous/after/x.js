export function other() {}
export function init() { return 3; }
