const f = (): number => 0;
namespace M {
  function f(): number { return 1; }
  export function g(): number { return f(); }
}
export function top(): number { return f(); }
