function f() { return 'top'; }
function g() {
  outer: {
    const f = () => 1;
    f();
    break outer;
  }
  return f();
}
