class A { f() { return 'method'; } }
function g(x) {
  if (x) {
    function f() { return 'block'; }
    f();
  }
}
