function f() { return 'top'; }
function g() {
  const f = () => 1;
  if (true) { f(); }
  return f();
}
function k() { return f(); }
