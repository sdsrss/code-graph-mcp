function f() { return 'top'; }
async function g(xs) {
  for await (const x of xs) {
    const f = () => x;
    f();
  }
  return f();
}
