function f() { return 'top'; }
function g(a, b) {
  if (a) {
    return 0;
  } else if (b) {
    const f = () => 1;
    f();
  } else {
    f();
  }
  return f();
}
