function f() { return 'top'; }
function g() {
  for (let i = 0, f = () => i; i < 3; i++) {
    f();
  }
  return f();
}
