function f() { return 'top'; }
const g = (x) => x ? (() => { const f = () => 1; return f(); })() : f();
