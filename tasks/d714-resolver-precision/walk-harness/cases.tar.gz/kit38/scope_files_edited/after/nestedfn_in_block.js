// edited
function f() { return 'top'; }
function g(x) {
  if (x) {
    const f = () => 1;
    function inner() { return f(); }
    return inner();
  }
  function other() { return f(); }
  return other();
}
