function f() { return 'top'; }
function g() {
  try {
    const f = () => 1;
    f();
  } finally {
    f();
  }
}
