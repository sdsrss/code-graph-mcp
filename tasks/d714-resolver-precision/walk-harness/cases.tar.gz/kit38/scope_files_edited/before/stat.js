const h = () => 'top';
class C {
  static {
    const h = () => 'static';
    h();
  }
  m() { return h(); }
}
function use() { return h(); }
