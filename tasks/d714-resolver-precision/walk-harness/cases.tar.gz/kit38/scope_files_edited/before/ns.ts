function f(): number { return 0; }
namespace N {
  export const f = (): number => 1;
}
namespace N {
  export function g(): number { return f(); }
}
export function top(): number { return f(); }
