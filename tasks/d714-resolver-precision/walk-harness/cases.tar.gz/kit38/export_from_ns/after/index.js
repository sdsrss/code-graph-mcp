export * as ns from './crud.js';
export { init } from './crud2.js';
