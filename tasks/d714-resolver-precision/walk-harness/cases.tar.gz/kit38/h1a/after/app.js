import * as idx from './index.js';
export function main() { return idx.init(); }
