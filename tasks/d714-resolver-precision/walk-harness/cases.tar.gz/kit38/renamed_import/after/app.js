import { init as boot } from './index.js';
export function main() { return boot(); }
