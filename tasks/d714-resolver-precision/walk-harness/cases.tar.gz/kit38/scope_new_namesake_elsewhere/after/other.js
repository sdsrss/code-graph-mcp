export function f() { return 'other'; }
export const h = () => 'other';
