export { init } from './b.js';
