import { init } from './a.js';
export function main() { return init(); }
