export { init } from './a.js';
