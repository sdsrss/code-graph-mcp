export function initOld() { return 1; }
