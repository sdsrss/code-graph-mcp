# mutate.py [NAME...]: apply each mutation to /var/tmp/agent-tmp-review-0189/mut, run `cargo test --lib`, record failures, restore.
import subprocess, sys, os, re, time
ROOT = "/var/tmp/agent-tmp-review-0189/mut"
TGT = "/var/tmp/agent-tmp-review-0189/target-mut"
OUT = "/var/tmp/agent-tmp-review-0189/keep/results/mutations.txt"
R = "src/indexer/pipeline/resolve.rs"; I = "src/indexer/pipeline/index_files.rs"
M = [
 # restore path
 ("R1 restore by name", I, "let family_call = relation.as_str() == REL_CALLS", "let family_call = false && relation.as_str() == REL_CALLS", 1),
 ("R2 family_call ignores metadata", I, "&& super::resolve::may_widen_to_family(&src_lang, metadata.as_deref())\n                && batch_file_language", "&& [\"javascript\",\"typescript\",\"tsx\"].contains(&src_lang.as_str())\n                && batch_file_language", 1),
 ("R3 family_call includes same language", I, ".is_some_and(|l| super::resolve::family_fallback(&src_lang, l));", ".is_some_and(|l| [\"javascript\",\"typescript\",\"tsx\"].contains(&l));", 1),
 ("R4 no requeued_family_sources insert", I, "requeued_family_sources.insert(src_path.clone());", "let _ = &requeued_family_sources;", 1),
 ("R5 scope every requeued call", I, "if family_call {\n                        requeued_family_sources.insert", "if true {\n                        requeued_family_sources.insert", 1),
 # FileImports
 ("F1 walked always true", R, "let walked = spec.is_some_and(|spec| {", "let walked = true || spec.is_some_and(|spec| {", 1),
 ("F2 one walked import suffices", R, ".map(|(t, w)| (t, w && walked));", ".map(|(t, w)| (t, w || walked));", 1),
 ("F3 first import target wins", R, ".filter(|(t, _)| *t == target)", ".filter(|_| true)", 1),
 ("F4 external targets counted", R, "WHERE f.path = ?1\n                   AND itf.path <> '<external>'", "WHERE f.path = ?1\n                   AND 1", 1),
 ("F5 attr imports counted", R, "AND itf.path <> '<external>'\n                   AND json_extract(ie.metadata, '$.attr') IS NULL\",", "AND itf.path <> '<external>'\",", 1),
 ("F6 keyed by target name", R, "\"SELECT COALESCE(json_extract(ie.metadata, '$.imported'), itn.name),\n                        itn.id, json_extract(ie.metadata, '$.js_module')", "\"SELECT itn.name,\n                        itn.id, json_extract(ie.metadata, '$.js_module')", 1),
 ("F7 cache shared across files", R, "self.by_file.insert(file.to_string(), named);\n        }\n        Ok(self.by_file[file].get(name).copied().flatten())", "self.by_file.insert(file.to_string(), named);\n        }\n        Ok(self.by_file.values().next().unwrap().get(name).copied().flatten())", 1),
 # predicates
 ("W1 member calls widen", R, "JS_FAMILY.contains(&caller) && metadata.is_none()", "JS_FAMILY.contains(&caller)", 1),
 ("W1b member calls widen", R, "JS_FAMILY.contains(&caller) && metadata.is_none()", "JS_FAMILY.contains(&caller) && (metadata.is_none() || true)", 1),
 ("FF1 same language is a sibling", R, "caller != callee && JS_FAMILY.contains(&caller) && JS_FAMILY.contains(&callee)", "JS_FAMILY.contains(&caller) && JS_FAMILY.contains(&callee)", 1),
 ("FF2 any callee language", R, "caller != callee && JS_FAMILY.contains(&caller) && JS_FAMILY.contains(&callee)", "caller != callee && JS_FAMILY.contains(&caller)", 1),
 # sweep widening
 ("S1 sweep binds every sibling", R, "                    if siblings.contains(&target) {\n                        candidates = vec![target];", "                    if siblings.contains(&target) {\n                        candidates = siblings.clone();", 1),
 ("S2 sweep binds the import target unchecked", R, "                    if siblings.contains(&target) {\n                        candidates = vec![target];", "                    if true {\n                        candidates = vec![target];", 1),
 ("S3 sweep widens with own-language candidates", R, "        if candidates.is_empty()\n            && may_widen_to_family(&row.source_language", "        if true\n            && may_widen_to_family(&row.source_language", 1),
 ("S4 sweep never widens", R, "        if candidates.is_empty()\n            && may_widen_to_family(&row.source_language", "        if false\n            && may_widen_to_family(&row.source_language", 1),
 # deferred widening
 ("P1 deferred never widens", I, "            if same_language_targets.is_empty()\n                && super::resolve::may_widen_to_family", "            if false\n                && super::resolve::may_widen_to_family", 1),
 ("P2 deferred widens over own language", I, "            if same_language_targets.is_empty()\n                && super::resolve::may_widen_to_family", "            if true\n                && super::resolve::may_widen_to_family", 1),
 ("P3 deferred binds the import target unchecked", I, "                        if siblings.contains(&target) {\n                            same_language_targets = vec![target];", "                        if true {\n                            same_language_targets = vec![target];", 1),
 ("P4 deferred binds every sibling", I, "                        if siblings.contains(&target) {\n                            same_language_targets = vec![target];", "                        if siblings.contains(&target) {\n                            same_language_targets = siblings.clone();", 1),
 # D#747
 ("D1 member arm drains", R, "if pool.is_empty() {\n                    continue;\n                }\n                pool", "pool", 1),
 ("D2 fallback drains", R, "} else if pool.is_empty() {\n                            // Free functions only: buffered too (D#747).\n                            continue;\n                        } else {", "} else {", 1),
 # new-duplicate fan-out
 ("Q1 family fan-out dropped", R, "        paths.extend(\n            conn.prepare(&family_sql)?", "        if false { paths.extend(\n            conn.prepare(&family_sql)?", 1),
 ("Q2 family fan-out any target language", R, "AND tf.language IS NOT u.lang\n", "\n", 1),
 ("Q3 family fan-out any caller language", R, "CROSS JOIN files f ON f.id = src.file_id AND f.language IS u.lang\n         WHERE u.lang IN", "CROSS JOIN files f ON f.id = src.file_id\n         WHERE u.lang IN", 1),
]
fix = {"Q1 family fan-out dropped": ("                .collect::<std::result::Result<Vec<_>, _>>()?,\n        );\n        paths.sort_unstable();", "                .collect::<std::result::Result<Vec<_>, _>>()?,\n        ); }\n        paths.sort_unstable();")}
sel = sys.argv[1:]
env = dict(os.environ, CARGO_TARGET_DIR=TGT, PATH=os.path.expanduser("~/.cargo/bin") + ":" + os.environ["PATH"])
os.makedirs(os.path.dirname(OUT), exist_ok=True)
for name, path, old, new, cnt in M:
    if sel and not any(name.startswith(s + " ") or name == s for s in sel): continue
    p = os.path.join(ROOT, path); src = open(p).read()
    if src.count(old) != cnt:
        print(f"== {name}: ANCHOR COUNT {src.count(old)}", flush=True); open(OUT, "a").write(f"== {name}: ANCHOR COUNT {src.count(old)}\n"); continue
    mutated = src.replace(old, new)
    if name in fix:
        a, b = fix[name]; assert mutated.count(a) == 1, name; mutated = mutated.replace(a, b)
    open(p, "w").write(mutated)
    t = time.time()
    try:
        r = subprocess.run(["cargo", "test", "--lib"], cwd=ROOT, env=env, capture_output=True, text=True)
        out = r.stdout + r.stderr
        res = re.findall(r"test result: .*", out)
        fails = re.findall(r"^test (\S+) \.\.\. FAILED", out, re.M)
        ce = "COMPILE ERROR" if "error[" in out or "error:" in out and not res else ""
        line = f"== {name}: {'KILLED' if fails else ('SURVIVED' if res else 'NO-RESULT')} {ce} fails={len(fails)} {res} ({int(time.time()-t)}s)"
        print(line, flush=True)
        with open(OUT, "a") as o:
            o.write(line + "\n")
            for f in fails: o.write(f"    {f}\n")
            if ce: o.write("\n".join(l for l in out.splitlines() if "error" in l)[:2000] + "\n")
    finally:
        open(p, "w").write(src)
