# cmpdet.py RESULTS.txt: for steps where both arms diverge, print the rel diff lines that base does not have
import sys, collections
res = sys.argv[1]; det = collections.defaultdict(list); cur = None
for l in open(res + ".detail"):
    if l.startswith("== "): cur = tuple(l[3:].split()); continue
    det[cur].append(l.rstrip("\n"))
st = {}
for l in open(res):
    c, s, a, r = l.split(); st[(c, s, a)] = r
both = same_set = 0; extra = []
for (c, s, a), r in st.items():
    if a != "rel" or r != "DIFF" or st.get((c, s, "base")) != "DIFF": continue
    both += 1
    rb, rr = set(det[(c, s, "base")]), set(det[(c, s, "rel")])
    if rr <= rb: same_set += 1
    else: extra.append((c, s, sorted(rr - rb), sorted(rb - rr)))
print(f"both DIFF: {both}; rel lines subset of base lines: {same_set}; rel has extra lines: {len(extra)}")
for c, s, x, y in extra:
    print("==", c, s); [print("  rel-extra", l) for l in x]; [print("  base-only", l) for l in y]
