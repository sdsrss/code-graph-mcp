# cana.py NAME: classify base->rel differences of corpus dumps out/NAME.{base,rel}.txt
import sys, re, collections, os
n = sys.argv[1]
A = open(f"{n}.base.txt").read().splitlines(); B = open(f"{n}.rel.txt").read().splitlines()
ca, cb = collections.Counter(A), collections.Counter(B)
minus = list((ca - cb).elements()); plus = list((cb - ca).elements())
ep = [l for l in plus if not l.startswith("PENDING ")]; em = [l for l in minus if not l.startswith("PENDING ")]
pp = [l for l in plus if l.startswith("PENDING ")]; pm = [l for l in minus if l.startswith("PENDING ")]
print(f"{n}: edges +{len(ep)} -{len(em)}; pending +{len(pp)} -{len(pm)}")
rx = re.compile(r"^([^:]+):(.*?)@(\d+) -(\w+)-> ([^:]+):(.*)@(\d+):(\w+) (\w+) ?(.*)$")
kinds = collections.Counter(); ext = collections.Counter(); keys = collections.Counter()
for l in ep:
    m = rx.match(l); 
    if not m: print("UNPARSED", l); continue
    sp, sn, sl, rel, tp, tn, tl, tt, conf, meta = m.groups()
    kinds[(rel, conf, meta or "NULL", tt)] += 1
    ext[(os.path.splitext(sp)[1], os.path.splitext(tp)[1])] += 1
    keys[(sp, sn, sl, tn)] += 1
print("  new edge kinds:", dict(kinds)); print("  caller->callee ext:", dict(ext))
# removed pending rows: same caller (path:name@line) and target name, NULL metadata
prx = re.compile(r"^PENDING ([^:]+):(.*?)@(\d+) => (\S+) ?(.*)$")
rem = collections.Counter()
for l in pm:
    m = prx.match(l); sp, sn, sl, tn, meta = m.groups(); rem[(sp, sn, sl, tn, meta or "NULL")] += 1
print("  removed pending metadata:", collections.Counter(k[4] for k in rem.elements()))
unmatched = [k for k in keys if (k[0], k[1], k[2], k[3], "NULL") not in rem]
print("  new edges without a removed NULL-metadata row of the same caller+name:", len(unmatched), unmatched[:5])
unm2 = [k for k in rem if (k[0], k[1], k[2], k[3]) not in keys]
print("  removed rows without a new edge:", len(unm2), unm2[:5])
addm = collections.Counter()
for l in pp:
    m = prx.match(l); meta = m.group(5) or "NULL"
    q = re.search(r'"q":"(\w+)"', meta); addm[q.group(1) if q else meta[:40]] += 1
print("  added pending rows by q:", dict(addm))
