#!/bin/bash
# both.sh CHAINDIR [ARMS...]: run walk-harness IVX on a private copy of CHAINDIR per arm; print one line per arm
W=/var/tmp/agent-tmp-review-0189; H=$W/src/tasks/d714-resolver-precision/walk-harness
C="$1"; shift; ARMS="${*:-base rel}"
for a in $ARMS; do
  R="$W/run/$(basename "$C")-$a"; rm -rf "${R:?}"; mkdir -p "$R"; cp -a "$C/." "$R/"
  rm -rf "${R:?}/w" "${R:?}/f"
  out=$("${IV:-$H/ivchain.sh}" "$W/bin/$a" "$R" 2>&1)
  echo "$a:"; echo "$out" | sed 's/^/    /'
done
