# steps.py OUT SET_DIR ARM[,ARM...] [-j N]: one-step chains (s_{k-1} fresh, s_k applied incrementally, vs a fresh s_k),
# edges with metadata + confidence (walk-harness edgesm.sh) and pending rows. Prints "<chain> s<k> <arm> SAME|DIFF" lines and a .detail file.
import os, sys, subprocess, shutil, multiprocessing, tempfile
W = "/var/tmp/agent-tmp-review-0189"; H = f"{W}/src/tasks/d714-resolver-precision/walk-harness"
PEND = "SELECT COALESCE(f.path,'?')||':'||n.name||' => '||p.target_name||' '||COALESCE(p.metadata,'') FROM pending_unresolved_calls p JOIN nodes n ON n.id=p.source_id LEFT JOIN files f ON f.id=n.file_id"
def sh(cmd, cwd=None):
    return subprocess.run(cmd, cwd=cwd, shell=isinstance(cmd, str), capture_output=True, text=True)
def gitinit(d):
    sh("git init -q && git add -A && git -c user.email=a@b -c user.name=a commit -qm i", cwd=d)
def index(binp, d):
    sh([binp, "incremental-index", "--no-embed", "--quiet"], cwd=d)
def dump(d):
    e = sh([f"{H}/edgesm.sh", d]).stdout
    p = sh(["sqlite3", "-readonly", f"file:{d}/.code-graph/index.db?mode=ro", PEND]).stdout
    return e + "".join(sorted("PENDING " + l + "\n" for l in p.splitlines()))
def copytree(src, dst):
    shutil.copytree(src, dst, dirs_exist_ok=True)
def job(args):
    chain, k, arm = args
    binp = f"{W}/bin/{arm}"
    tmp = tempfile.mkdtemp(prefix=f"agent-tmp-review-0189-st-", dir=f"{W}/run2")
    try:
        w = os.path.join(tmp, "w"); f = os.path.join(tmp, "f")
        prev, cur = os.path.join(chain, f"s{k-1}"), os.path.join(chain, f"s{k}")
        os.makedirs(w); copytree(prev, w); gitinit(w); index(binp, w)
        for r, ds, fs in os.walk(prev):
            for fn in fs:
                rel = os.path.relpath(os.path.join(r, fn), prev)
                if not os.path.exists(os.path.join(cur, rel)): os.remove(os.path.join(w, rel))
        copytree(cur, w); sh("git add -A && git -c user.email=a@b -c user.name=a commit -qm e", cwd=w); index(binp, w)
        os.makedirs(f); copytree(cur, f); gitinit(f); index(binp, f)
        a, b = dump(w), dump(f)
        if a == b: return (chain, k, arm, "SAME", "")
        al, bl = set(a.splitlines()), set(b.splitlines())
        det = "".join(f"  incremental-only: {l}\n" for l in sorted(al - bl)) + "".join(f"  rebuild-only: {l}\n" for l in sorted(bl - al))
        return (chain, k, arm, "DIFF", det)
    finally:
        shutil.rmtree(tmp, ignore_errors=True)
if __name__ == "__main__":
    out, setdir, arms = sys.argv[1], sys.argv[2], sys.argv[3].split(",")
    j = int(sys.argv[5]) if len(sys.argv) > 5 else 8
    os.makedirs(f"{W}/run2", exist_ok=True)
    jobs = []
    for c in sorted(os.listdir(setdir)):
        cd = os.path.join(setdir, c); k = 1
        while os.path.isdir(os.path.join(cd, f"s{k}")):
            for arm in arms: jobs.append((cd, k, arm))
            k += 1
    with multiprocessing.Pool(j) as pool, open(out, "w") as o, open(out + ".detail", "w") as od:
        for chain, k, arm, res, det in pool.imap_unordered(job, jobs, chunksize=4):
            o.write(f"{os.path.basename(chain)} s{k} {arm} {res}\n")
            if det: od.write(f"== {os.path.basename(chain)} s{k} {arm}\n{det}")
    print("done", len(jobs))
