import sys; sys.path.insert(0, "/var/tmp/agent-tmp-review-0189/keep/scripts")
from mk import make, chain
R = "/var/tmp/agent-tmp-review-0189/keep/cases"
A = "import { f } from './t';\nexport function A() { return f(); }\n"
T = "function r() { return 1; }\nexport { r as f };\n"
# r5: r1 then an unrelated tsx file defines r: the phantom row binds it
make(f"{R}/r5", chain({"t.ts": T, "b.tsx": "export function f() { return 'twin'; }\n", "a.tsx": A},
  {"t.ts": T + "// touched\n"},
  {"c.tsx": "export function r() { return 'unrelated'; }\n"}))
# r6: r1 then the twin goes away
make(f"{R}/r6", chain({"t.ts": T, "b.tsx": "export function f() { return 'twin'; }\n", "a.tsx": A},
  {"t.ts": T + "// touched\n"},
  {"b.tsx": None}))
