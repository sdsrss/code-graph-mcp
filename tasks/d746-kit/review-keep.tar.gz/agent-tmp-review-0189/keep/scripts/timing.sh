#!/bin/bash
# timing.sh RUNS NAME SRC FILE...: per arm a private copy of SRC; RUNS x (full index, then each FILE: append a comment + incremental), arms alternated base/rel; ms per run
W=/var/tmp/agent-tmp-review-0189; N="$1"; name="$2"; src="$3"; shift 3; P=$W/tp
ms() { local s e; s=$(date +%s%N); (cd "$1" && "$W/bin/$2" incremental-index --no-embed --quiet >/dev/null 2>&1); e=$(date +%s%N); echo $(( (e-s)/1000000 )); }
mkdir -p "$P"
for arm in ${ARMS:-base rel}; do rm -rf "${P:?}/$name-$arm"; cp -a "$src" "$P/$name-$arm"; rm -rf "${P:?}/$name-$arm/.code-graph"; done
declare -A R
for i in $(seq 1 "$N"); do
  for arm in ${ARMS:-base rel}; do rm -rf "${P:?}/$name-$arm/.code-graph"; R[full-$arm]+="$(ms "$P/$name-$arm" $arm) "; done
  for f in "$@"; do for arm in ${ARMS:-base rel}; do echo "// t$i" >> "$P/$name-$arm/$f"; R[$f-$arm]+="$(ms "$P/$name-$arm" $arm) "; done; done
done
for k in full "$@"; do line="$name $k |"; for arm in ${ARMS:-base rel}; do line="$line $arm: ${R[$k-$arm]}|"; done; echo "$line"; done
for arm in ${ARMS:-base rel}; do rm -rf "${P:?}/$name-$arm"; done
