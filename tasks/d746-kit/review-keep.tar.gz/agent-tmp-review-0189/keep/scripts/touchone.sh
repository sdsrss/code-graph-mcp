#!/bin/bash
# touchone.sh ARM CORPUS FILE: index a copy of CORPUS, append a comment to FILE, incremental; compare edges(+metadata,+confidence)+pending rows with a fresh index
W=/var/tmp/agent-tmp-review-0189; H=$W/src/tasks/d714-resolver-precision/walk-harness; A="$1"; C="$2"; F="$3"
X="$W/walk/touch-$A"; Y="$X-full"; rm -rf "${X:?}" "${Y:?}"; mkdir -p "$X"; cp -a "$C/." "$X/"; rm -rf "${X:?}/.code-graph"
(cd "$X" && "$W/bin/$A" incremental-index --no-embed --quiet >/dev/null 2>&1)
echo "// touched" >> "$X/$F"; (cd "$X" && git add -A && git -c user.email=a@b -c user.name=a commit -qm e >/dev/null 2>&1; "$W/bin/$A" incremental-index --no-embed --quiet >/dev/null 2>&1)
mkdir -p "$Y"; cp -a "$X/." "$Y/"; rm -rf "${Y:?}/.code-graph"; (cd "$Y" && "$W/bin/$A" incremental-index --no-embed --quiet >/dev/null 2>&1)
pend() { sqlite3 -readonly "file:$1/.code-graph/index.db?mode=ro" "SELECT COALESCE(f.path,'?')||':'||n.name||' => '||p.target_name||' '||COALESCE(p.metadata,'') FROM pending_unresolved_calls p JOIN nodes n ON n.id=p.source_id LEFT JOIN files f ON f.id=n.file_id" | sort | sed 's/^/PENDING /'; }
{ "$H/edgesm.sh" "$X"; pend "$X"; } > "$X.txt"; { "$H/edgesm.sh" "$Y"; pend "$Y"; } > "$Y.txt"
echo "$A touch $F: incremental-only $(diff "$X.txt" "$Y.txt" | grep -c '^<') rebuild-only $(diff "$X.txt" "$Y.txt" | grep -c '^>')"
diff "$X.txt" "$Y.txt" | grep '^[<>]' | head -6
rm -rf "${X:?}" "${Y:?}" "$X.txt" "$Y.txt"
