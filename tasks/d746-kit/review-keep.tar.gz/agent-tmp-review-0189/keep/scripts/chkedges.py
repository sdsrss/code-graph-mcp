# chkedges.py CORPUS: for every call edge rel has and base lacks, find the caller file's import of the callee's name
# (from source text) and follow its specifier (and one level of `export ... from` barrels) to the callee's file.
import sys, re, os, collections
W = "/var/tmp/agent-tmp-review-0189"; n = sys.argv[1]; root = f"{W}/corpora/{n}"
A = collections.Counter(open(f"{W}/out/{n}.base.txt").read().splitlines()); B = collections.Counter(open(f"{W}/out/{n}.rel.txt").read().splitlines())
rx = re.compile(r"^([^:]+):(.*?)@(\d+) -(\w+)-> ([^:]+):(.*)@(\d+):(\w+) (\w+) ?(.*)$")
EXTS = ["", ".ts", ".tsx", ".js", ".jsx", ".mjs", ".cjs", "/index.ts", "/index.tsx", "/index.js"]
def resolve(spec, frm):
    if not spec.startswith("."): return None
    base = os.path.normpath(os.path.join(os.path.dirname(frm), spec))
    cands = [base + e for e in EXTS]
    if base.endswith(".js"): cands += [base[:-3] + ".ts", base[:-3] + ".tsx"]
    for c in cands:
        if os.path.isfile(os.path.join(root, c)): return c
    return None
IMP = re.compile(r"import\s+(?:type\s+)?(?:[\w$]+\s*,\s*)?\{([^}]*)\}\s*from\s*['\"]([^'\"]+)['\"]", re.S)
EXP = re.compile(r"export\s+(?:type\s+)?\{([^}]*)\}\s*from\s*['\"]([^'\"]+)['\"]|export\s*\*\s*from\s*['\"]([^'\"]+)['\"]", re.S)
def imports_of(path):
    src = open(os.path.join(root, path), errors="replace").read(); out = []
    for m in IMP.finditer(src):
        for item in m.group(1).split(","):
            item = item.strip().replace("type ", "")
            if not item: continue
            parts = re.split(r"\s+as\s+", item); out.append((parts[0].strip(), parts[-1].strip(), m.group(2)))
    return out
def reaches(file, name, target, depth=0):
    if file == target: return True
    if depth > 3 or file is None: return False
    src = open(os.path.join(root, file), errors="replace").read()
    for m in EXP.finditer(src):
        if m.group(3):
            if reaches(resolve(m.group(3), file), name, target, depth + 1): return True
        else:
            for item in m.group(1).split(","):
                parts = re.split(r"\s+as\s+", item.strip())
                if parts[-1].strip() == name and reaches(resolve(m.group(2), file), parts[0].strip(), target, depth + 1): return True
    # import-then-export barrel: `import { a as name } from 'x'` and an `export { ..., name, ... }` list
    lists = re.findall(r"export\s*\{([^}]*)\}(?!\s*from)", src, re.S)
    exported = {re.split(r"\s+as\s+", i.strip())[0].strip() for l in lists for i in l.split(",")}
    for orig, loc, spec in imports_of(file):
        if loc == name and name in exported and reaches(resolve(spec, file), orig, target, depth + 1): return True
    return False
res = collections.Counter(); bad = []
for l in (B - A).elements():
    if l.startswith("PENDING"): continue
    m = rx.match(l); sp, sn, sl, rel, tp, tn, tl, tt, conf, meta = m.groups()
    hits = [(orig, loc, spec) for orig, loc, spec in imports_of(sp) if loc == tn]
    if not hits: res["no import of the name"] += 1; bad.append((l, "no import")); continue
    if len(hits) > 1 and len({h[2] for h in hits}) > 1: res["several imports"] += 1
    ok = all(h[0] == tn and reaches(resolve(h[2], sp), tn, tp) for h in hits)
    res["import reaches callee file" if ok else "import does NOT reach callee file"] += 1
    if not ok: bad.append((l, hits))
print(n, dict(res))
for b in bad[:20]: print("  ", b)
