# mbuild.py NAME...: build a debug binary of each mutation (from mutate.py's list) in /var/tmp/agent-tmp-review-0189/mb as bin/m-<TAG>
import os, sys, subprocess
W = "/var/tmp/agent-tmp-review-0189"
src = open(f"{W}/keep/scripts/mutate.py").read().split("sel = sys.argv")[0]
g = {}; exec(src.replace("import subprocess, sys, os, re, time", "import os"), g)
M, fix = g["M"], g["fix"]
env = dict(os.environ, CARGO_TARGET_DIR=f"{W}/target-mb", PATH=os.path.expanduser("~/.cargo/bin") + ":" + os.environ["PATH"])
for want in sys.argv[1:]:
    for name, path, old, new, cnt in M:
        if not name.startswith(want + " "): continue
        p = os.path.join(W, "mb", path); s = open(p).read(); assert s.count(old) == cnt, name
        m = s.replace(old, new)
        if name in fix: a, b = fix[name]; m = m.replace(a, b)
        open(p, "w").write(m)
        try:
            r = subprocess.run(["cargo", "build"], cwd=f"{W}/mb", env=env, capture_output=True, text=True)
            ok = r.returncode == 0
            if ok: subprocess.run(["cp", f"{W}/target-mb/debug/code-graph-mcp", f"{W}/bin/m-{want}"])
            print(name, "built" if ok else "BUILD FAILED\n" + r.stderr[-1500:], flush=True)
        finally:
            open(p, "w").write(s)
