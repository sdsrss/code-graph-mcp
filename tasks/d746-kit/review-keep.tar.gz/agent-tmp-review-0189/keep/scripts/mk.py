# mk.py OUTDIR CASE.json -- or import: make(outdir, [state0_dict, state1_dict, ...])
import os, shutil, sys, json
def make(out, states):
    if os.path.exists(out): shutil.rmtree(out)
    for i, st in enumerate(states):
        for fn, body in st.items():
            p = os.path.join(out, f"s{i}", fn); os.makedirs(os.path.dirname(p), exist_ok=True)
            open(p, "w").write(body)
def chain(base, *edits):
    """base: dict; each edit: dict of fn -> body (None deletes). Returns list of states."""
    sts = [dict(base)]
    for e in edits:
        s = dict(sts[-1])
        for k, v in e.items():
            if v is None: s.pop(k, None)
            else: s[k] = v
        sts.append(s)
    return sts
