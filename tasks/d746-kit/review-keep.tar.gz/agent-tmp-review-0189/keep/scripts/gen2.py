# gen2.py ROOT N SEED STEPS: JS-family edit chains (deterministic, no set iteration). Each chain ROOT/g<SEED>_<i>/s0..sSTEPS.
# Adds to famgen.py: callee files touched, callee gaining a second node of the name (class/object method,
# nested, namespace), own-language twins (function / method / renamed-internal namesake), barrels in any
# family language, member-only callers, namespace-import callers, unindexed-path imports.
import os, random, shutil, sys
root, n, seed, steps = sys.argv[1], int(sys.argv[2]), int(sys.argv[3]), int(sys.argv[4])
rng = random.Random(seed)
EXT = ["ts", "tsx", "js"]
T = {
 "DIRECT": "export function f() { return 1; }\n",
 "RENAMED": "function r() { return 1; }\nexport { r as f };\n",
 "CLASSM": "export function f() { return 1; }\nexport class K { f() { return 2; } }\n",
 "NESTED": "export function f() { return 1; }\nexport function q() { function f() { return 3; } return f(); }\n",
 "OBJM": "export function f() { return 1; }\nexport const o = { f() { return 4; } };\n",
 "NS": "export function f() { return 1; }\nexport namespace N { export function f() { return 5; } }\n",
 "ARROW": "export const f = () => 1;\n",
 "DEFAULT": "export default function f() { return 1; }\n",
 "NONE": "export const z = 1;\n",
 "FWD_U": "export { f } from './u';\n",
 "STAR_U": "export * from './u';\n",
 "IMPEXP": "import { f } from './u';\nexport { f };\n",
 "TWO": "export function f() { return 1; }\nexport function q() { return f(); }\n",
}
U = {"DIRECT": "export function f() { return 'u'; }\n", "NONE": "export const y = 1;\n",
     "RENAMED": "function s() { return 'u'; }\nexport { s as f };\n",
     "CLASSM": "export function f() { return 'u'; }\nexport class KU { f() { return 'k'; } }\n"}
B = {"F": "export function f() { return 'twin'; }\n", "M": "export class B { f() { return 'm'; } }\n",
     "R": "export function r() { return 'rr'; }\n", "NONE": "export const w = 1;\n", "ABSENT": None}
IDX = {"FWD_T": "export { f } from './t';\n", "STAR_T": "export * from './t';\n", "FWD_U": "export { f } from './u';\n", "ABSENT": None}
CALLERS = {
 "a": "import { f } from './t';\nexport function A() { return f(); }\n",
 "k": "import { f } from './t';\nexport function K(o: any) { o.f(); return f(); }\n",
 "n": "import { f as g } from './t';\nexport function N(x: any) { return g() + f(); }\n",
 "i": "import { f } from './idx';\nexport function I() { return f(); }\n",
 "m": "export function M() { return f(); }\n",
 "x": "import { f } from './t';\nimport { f as h } from './u';\nexport function X() { return f() + h(); }\n",
 "d": "import { f } from '../dist/t';\nexport function D() { return f(); }\n",
 "e": "export function E(o: any) { return o.f(); }\n",
 "y": "import { f } from './u';\nexport function Y() { return f(); }\n",
 "z": "import * as T from './t';\nexport function Z() { return T.f(); }\n",
}
def jsify(body, ext):
    if ext != "js": return body
    return body.replace("(x: any)", "(x)").replace("(o: any)", "(o)")
def tbody(st):
    k = st["t"]
    if k == "NS" and st["ext"]["t"] == "js": k = "CLASSM"
    return T[k]
def tree(st):
    fs = {}
    def put(key, body):
        if body is None: return
        fs[key + "." + st["ext"][key]] = jsify(body, st["ext"][key]) + ("// touched %d\n" % st["touch"][key] if st["touch"].get(key) else "")
    put("t", tbody(st)); put("u", U[st["u"]]); put("b", B[st["b"]]); put("idx", IDX[st["idx"]])
    for c in st["callers"]: put(c, CALLERS[c])
    return fs
CN = sorted(CALLERS)
for ci in range(n):
    names = ["t", "u", "b", "idx"] + CN
    st = {"t": rng.choice(sorted(T)), "u": rng.choice(sorted(U)), "b": rng.choice(sorted(B)), "idx": rng.choice(sorted(IDX)),
          "ext": {k: rng.choice(EXT) for k in names},
          "callers": sorted(rng.sample(CN, rng.randint(1, 4))), "touch": {}}
    dd = os.path.join(root, f"g{seed}_{ci}")
    if os.path.exists(dd): shutil.rmtree(dd)
    for s in range(steps + 1):
        if s > 0:
            for _ in range(rng.randint(1, 2)):
                k = rng.random()
                if k < 0.2: st["t"] = rng.choice(sorted(T))
                elif k < 0.27: st["u"] = rng.choice(sorted(U))
                elif k < 0.37: st["b"] = rng.choice(sorted(B))
                elif k < 0.44: st["idx"] = rng.choice(sorted(IDX))
                elif k < 0.6: st["ext"][rng.choice(names)] = rng.choice(EXT)
                elif k < 0.7:
                    c = rng.choice(CN)
                    st["callers"] = sorted(set(st["callers"]) ^ {c}) or ["a"]
                else:
                    present = [x for x in ["t", "u", "b", "idx"] + st["callers"] if x in st["callers"] or x in ("t", "u") or (x == "b" and B[st["b"]]) or (x == "idx" and IDX[st["idx"]])]
                    x = rng.choice(present); st["touch"][x] = st["touch"].get(x, 0) + 1
        for fn, body in tree(st).items():
            p = os.path.join(dd, f"s{s}", fn); os.makedirs(os.path.dirname(p), exist_ok=True)
            open(p, "w").write(body)
