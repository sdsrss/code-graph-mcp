import sys; sys.path.insert(0, "/var/tmp/agent-tmp-review-0189/keep/scripts")
from mk import make, chain
R = "/var/tmp/agent-tmp-review-0189/keep/cases"
A = "import { f } from './t';\nexport function A() { return f(); }\n"
# r1: renamed export in a sibling file, own-language twin; callee touched
make(f"{R}/r1", chain({
  "t.ts": "function r() { return 1; }\nexport { r as f };\n",
  "b.tsx": "export function f() { return 'twin'; }\n",
  "a.tsx": A}, {"t.ts": "function r() { return 1; }\nexport { r as f };\n// touched\n"}))
# r2: same, js callee
make(f"{R}/r2", chain({
  "t.js": "function r() { return 1; }\nexport { r as f };\n",
  "b.tsx": "export function f() { return 'twin'; }\n",
  "a.tsx": A}, {"t.js": "function r() { return 1; }\nexport { r as f };\n// touched\n"}))
# r3: caller makes a member call too (prune keeps twin edge)
make(f"{R}/r3", chain({
  "t.ts": "function r() { return 1; }\nexport { r as f };\n",
  "b.tsx": "export function f() { return 'twin'; }\n",
  "a.tsx": "import { f } from './t';\nexport function A(o: any) { o.f(); return f(); }\n"},
  {"t.ts": "function r() { return 1; }\nexport { r as f };\n// touched\n"}))
# r4: same-language control (ts caller) -- not family
make(f"{R}/r4", chain({
  "t.ts": "function r() { return 1; }\nexport { r as f };\n",
  "b.ts": "export function f() { return 'twin'; }\n",
  "a.ts": A}, {"t.ts": "function r() { return 1; }\nexport { r as f };\n// touched\n"}))
