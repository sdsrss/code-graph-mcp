#!/bin/bash
# cdiff.sh ARM_A ARM_B NAME...: full index of corpora/NAME with each arm (in a private copy); dump edges+metadata+confidence and pending rows (with source line) to out/NAME.ARM.txt
W=/var/tmp/agent-tmp-review-0189; H=$W/src/tasks/d714-resolver-precision/walk-harness; A="$1"; B="$2"; shift 2
mkdir -p "$W/out"
for n in "$@"; do
  for arm in "$A" "$B"; do
    c="$W/cx/$n-$arm"; rm -rf "${c:?}"; mkdir -p "$c"; cp -a "$W/corpora/$n/." "$c/"
    (cd "$c" && "$W/bin/$arm" incremental-index --no-embed --quiet >/dev/null 2>&1)
    "$H/edgesm.sh" "$c" > "$W/out/$n.$arm.txt"
    sqlite3 -readonly "file:$c/.code-graph/index.db?mode=ro" "SELECT COALESCE(f.path,'?')||':'||n.name||'@'||n.start_line||' => '||p.target_name||' '||COALESCE(p.metadata,'') FROM pending_unresolved_calls p JOIN nodes n ON n.id=p.source_id LEFT JOIN files f ON f.id=n.file_id" | sort | sed 's/^/PENDING /' >> "$W/out/$n.$arm.txt"
    rm -rf "${c:?}"
  done
  ea=$(grep -vc '^PENDING' "$W/out/$n.$A.txt"); pa=$(grep -c '^PENDING' "$W/out/$n.$A.txt")
  d=$(diff "$W/out/$n.$A.txt" "$W/out/$n.$B.txt" | grep '^[<>]')
  echo "$n edges($A)=$ea pending($A)=$pa  edges -$(echo "$d" | grep -v '^< PENDING ' | grep -c '^<') +$(echo "$d" | grep -v '^> PENDING ' | grep -c '^>')  pending -$(echo "$d" | grep -c '^< PENDING') +$(echo "$d" | grep -c '^> PENDING')"
done
