# advgen.py ROOT KIND: adversarial cost trees
#  fanin  : lib/m.ts with 50 functions; 4000 .tsx files each import and call 10 of them (40,000 cross-language bare calls into one file)
#  sibonly: 4000 .tsx files each call g0..g9 that only lib/g.js defines and none imports (40,000 pending rows of sibling-only names), plus a small .ts import each
#  freefn : 4000 .js files each make 10 member calls o.h0()..o.h9(); lib/h.js defines free functions h0..h9 only (40,000 member rows D#747 keeps)
import os, sys
root, kind = sys.argv[1], sys.argv[2]
def w(p, s):
    p = os.path.join(root, p); os.makedirs(os.path.dirname(p), exist_ok=True); open(p, "w").write(s)
if kind == "fanin":
    w("lib/m.ts", "".join(f"export function a{j}() {{ return {j}; }}\n" for j in range(50)))
    for i in range(4000):
        names = [f"a{(i + j) % 50}" for j in range(10)]
        w(f"app/f{i}.tsx", f"import {{ {', '.join(names)} }} from '../lib/m';\nexport function u{i}() {{ return {' + '.join(n + '()' for n in names)}; }}\n")
elif kind == "sibonly":
    w("lib/g.js", "".join(f"export function g{j}() {{ return {j}; }}\n" for j in range(10)))
    w("lib/m.ts", "export function a0() { return 0; }\n")
    for i in range(4000):
        w(f"app/f{i}.tsx", f"import {{ a0 }} from '../lib/m';\nexport function u{i}() {{ return a0() + {' + '.join(f'g{j}()' for j in range(10))}; }}\n")
elif kind == "freefn":
    w("lib/h.js", "".join(f"export function h{j}() {{ return {j}; }}\n" for j in range(10)))
    for i in range(4000):
        w(f"app/f{i}.js", f"export function u{i}(o) {{ return {' + '.join(f'o.h{j}()' for j in range(10))}; }}\n")
