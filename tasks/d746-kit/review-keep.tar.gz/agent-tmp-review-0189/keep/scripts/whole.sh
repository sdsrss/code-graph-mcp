#!/bin/bash
# whole.sh SET ARM: whole chains (walk-harness ivchain.sh: first differing step) of the author's chain set copy, 6 in parallel
W=/var/tmp/agent-tmp-review-0189; H=$W/src/tasks/d714-resolver-precision/walk-harness; S="$1"; A="$2"
R="$W/run3/$S-$A"; rm -rf "${R:?}"; mkdir -p "$R"; cp -a "/var/tmp/agent-tmp-d746/sets/$S/." "$R/"
ls "$R" | xargs -P 6 -I{} sh -c 'echo "{} $('"$H"'/ivchain.sh '"$W/bin/$A"' '"$R"'/{} 2>&1 | head -1)"' | sort > "$W/keep/results/whole-$S-$A.txt"
echo "$S $A: $(grep -c DIFF "$W/keep/results/whole-$S-$A.txt") DIFF / $(wc -l < "$W/keep/results/whole-$S-$A.txt")"
rm -rf "${R:?}"
