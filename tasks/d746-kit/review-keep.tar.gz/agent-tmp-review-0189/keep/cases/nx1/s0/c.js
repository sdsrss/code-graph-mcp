export function f() { return 'decoy'; }
