import { debounce } from './t';
export function A() { return debounce(); }
