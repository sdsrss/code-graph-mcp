module.exports = { f: require('./impl').run };
// t
