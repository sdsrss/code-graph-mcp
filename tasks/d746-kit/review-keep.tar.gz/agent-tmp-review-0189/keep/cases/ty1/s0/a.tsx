import type { f } from './t';
export function A(f: any) { return f(); }
