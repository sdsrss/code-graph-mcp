import { f } from './t';
import { f as g } from 'react';
export function A() { return f() + g(); }
