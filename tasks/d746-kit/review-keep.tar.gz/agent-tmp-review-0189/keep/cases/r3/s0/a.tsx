import { f } from './t';
export function A(o: any) { o.f(); return f(); }
