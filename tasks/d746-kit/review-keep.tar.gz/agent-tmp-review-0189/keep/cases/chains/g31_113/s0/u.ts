export function f() { return 'u'; }
export class KU { f() { return 'k'; } }
