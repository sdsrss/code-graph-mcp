export function f() { return 1; }
export class K { f() { return 2; } }
