import { f as g } from './t';
export function N(x: any) { return g() + f(); }
