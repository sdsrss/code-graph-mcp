export * from './t';
// touched 1
