export function f() { return 'u'; }
// touched 1
