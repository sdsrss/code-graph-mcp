function r() { return 1; }
export { r as f };
// touched 1
