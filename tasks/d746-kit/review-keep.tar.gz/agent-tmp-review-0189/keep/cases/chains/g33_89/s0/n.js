import { f as g } from './t';
export function N(x) { return g() + f(); }
