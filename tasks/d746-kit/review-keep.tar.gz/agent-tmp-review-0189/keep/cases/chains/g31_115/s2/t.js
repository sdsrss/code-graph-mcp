function r() { return 1; }
export { r as f };
