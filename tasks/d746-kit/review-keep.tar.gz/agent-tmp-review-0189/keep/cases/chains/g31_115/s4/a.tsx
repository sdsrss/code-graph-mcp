import { f } from './t';
export function A() { return f(); }
// touched 1
