import { f } from './idx';
export function I() { return f(); }
