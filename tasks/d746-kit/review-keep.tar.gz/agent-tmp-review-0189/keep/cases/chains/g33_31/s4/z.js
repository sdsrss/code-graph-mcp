import * as T from './t';
export function Z() { return T.f(); }
