import { f } from './u';
export function Y() { return f(); }
// touched 1
