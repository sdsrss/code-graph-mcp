export class B { f() { return 'm'; } }
// touched 1
