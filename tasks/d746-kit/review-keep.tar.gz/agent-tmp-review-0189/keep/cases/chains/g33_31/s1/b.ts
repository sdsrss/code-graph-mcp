export class B { f() { return 'm'; } }
