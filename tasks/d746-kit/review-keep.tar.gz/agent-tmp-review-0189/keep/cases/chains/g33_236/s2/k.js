import { f } from './t';
export function K(o) { o.f(); return f(); }
// touched 1
