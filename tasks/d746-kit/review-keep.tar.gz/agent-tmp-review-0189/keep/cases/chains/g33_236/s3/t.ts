export function f() { return 1; }
export function q() { function f() { return 3; } return f(); }
// touched 1
