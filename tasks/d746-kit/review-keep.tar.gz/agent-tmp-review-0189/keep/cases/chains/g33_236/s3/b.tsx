export function f() { return 'twin'; }
// touched 2
