export function f() { return 1; }
export const o = { f() { return 4; } };
