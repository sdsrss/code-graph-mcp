export function M() { return f(); }
