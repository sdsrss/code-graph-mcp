export function f() { return 'u'; }
