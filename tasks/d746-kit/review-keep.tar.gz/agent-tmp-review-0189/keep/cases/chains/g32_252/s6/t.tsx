export { f } from './u';
// touched 2
