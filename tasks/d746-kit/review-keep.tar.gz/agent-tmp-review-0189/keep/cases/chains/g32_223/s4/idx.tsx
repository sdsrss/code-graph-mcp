export { f } from './t';
// touched 1
