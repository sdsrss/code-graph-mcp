export function f() { return 1; }
export namespace N { export function f() { return 5; } }
