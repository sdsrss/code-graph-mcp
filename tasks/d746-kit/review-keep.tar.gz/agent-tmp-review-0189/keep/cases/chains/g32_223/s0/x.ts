import { f } from './t';
import { f as h } from './u';
export function X() { return f() + h(); }
