import { f } from '../dist/t';
export function D() { return f(); }
// touched 1
