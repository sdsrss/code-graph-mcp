function s() { return 'u'; }
export { s as f };
