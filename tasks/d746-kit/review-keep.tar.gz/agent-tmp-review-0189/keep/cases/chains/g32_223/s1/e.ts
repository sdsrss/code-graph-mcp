export function E(o: any) { return o.f(); }
