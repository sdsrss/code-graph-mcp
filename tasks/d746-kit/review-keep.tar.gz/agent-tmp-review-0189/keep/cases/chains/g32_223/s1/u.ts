function s() { return 'u'; }
export { s as f };
// touched 1
