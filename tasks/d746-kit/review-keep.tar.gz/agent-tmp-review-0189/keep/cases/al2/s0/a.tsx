import { f as g } from './t';
export function A() { return f() + g(); }
