import { f } from './t';
import { f as g } from 'pkg';
export function A() { return f() + g(); }
