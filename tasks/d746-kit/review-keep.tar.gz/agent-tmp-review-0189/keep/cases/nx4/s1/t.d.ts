export declare const g: number;
// t
